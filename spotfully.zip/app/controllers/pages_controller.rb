class PagesController < ApplicationController


    

end
